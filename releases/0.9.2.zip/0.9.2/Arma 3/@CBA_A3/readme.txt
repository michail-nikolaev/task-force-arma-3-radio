Release Candidate 1
Launch with -mod=@CBA_A3

*** KNOWN ISSUES ***
None at this time

*** Change Log ***
CBA_A3_RC1 Roadmap - http://dev.withsix.com/versions/1488