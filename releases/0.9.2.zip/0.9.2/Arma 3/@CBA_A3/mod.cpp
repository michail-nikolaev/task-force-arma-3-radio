name = "Community Base Addons v1.06.140320";
picture = "logo_cba_ca.paa";
actionName = "Website";
action = "http://dev.withsix.com/projects/cca";
description = "Bugtracker: http://dev.withsix.com/projects/cca<br />Documentation: http://dev.withsix.com/projects/cca";
