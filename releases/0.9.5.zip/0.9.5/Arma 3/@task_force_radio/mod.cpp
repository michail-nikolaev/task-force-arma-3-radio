name = "Task Force Arrowhead Radio 0.9.5";
picture = "task_force_arrowhead_logo.paa";
actionName = "Website";
action = "http://radio.task-force.ru/en";
description = "Task Force Arrowhead TeamSpeak Radio Plugin";
