name = "Task Force Arrowhead Radio";
picture = "task_force_arrowhead_logo.paa";
actionName = "Website";
action = "http://michail-nikolaev.github.io/task-force-arma-3-radio/";
description = "Task Force Arrowhead TeamSpeak Radio Plugin";
