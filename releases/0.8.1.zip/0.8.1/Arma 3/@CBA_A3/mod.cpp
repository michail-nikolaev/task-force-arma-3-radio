name = "Community Base Addons: A3 Beta";
picture = "logo_cba_ca.paa";
actionName = "Website";
action = "http://dev-heaven.net/projects/cca";
description = "Bugtracker: http://dev-heaven.net/projects/cca<br />Documentation: http://dev-heaven.net/projects/cca";
