Beta release, recommended for testing

Launch with -mod=@CBA_A3



*** KNOWN ISSUES ***

None at this time
