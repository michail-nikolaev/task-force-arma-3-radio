name = "Task Force Arrowhead Radio";
picture = "task_force_arrowhead_logo.paa";
actionName = "Website";
action = "http://radio.task-force.ru/en";
description = "Task Force Arrowhead Radio";
