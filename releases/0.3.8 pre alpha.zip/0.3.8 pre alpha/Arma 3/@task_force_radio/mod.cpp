name = "Task Force Arrowhead Radio";
picture = "task_force_arrowhead_logo.paa";
actionName = "Website";
action = "https://github.com/michail-nikolaev/task-force-arma-3-radio#task-force-arma-3-radio";
description = "Task Force Arrowhead TeamSpeak Radio Plugin";
